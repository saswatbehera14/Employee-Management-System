-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2021 at 09:26 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employee_info`
--

-- --------------------------------------------------------

--
-- Table structure for table `employeedetails`
--

CREATE TABLE `employeedetails` (
  `Eid` varchar(30) NOT NULL,
  `EmployeeName` varchar(100) NOT NULL,
  `Date of Joining` varchar(40) NOT NULL,
  `Department` varchar(30) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `ContactNo` int(20) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Date of Leaving` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employeedetails`
--

INSERT INTO `employeedetails` (`Eid`, `EmployeeName`, `Date of Joining`, `Department`, `Address`, `Gender`, `ContactNo`, `Email`, `Date of Leaving`) VALUES
('1', 'NITISH RANA', '15/12/2015', 'IT', 'BBSR', 'MALE', 985234125, 'nitishrana1@gmail.com', '20/12/2020'),
('2', 'Goutham Gambhir', '15/12/2015', 'IT', 'Puri', 'MALE', 985234125, 'ggoutham@gmail.com', '20/12/2020');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
