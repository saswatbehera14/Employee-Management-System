<!DOCTYPE html>
<html lang="en">
<head>
  <title>Registration</title>
<style> 
html { 
  background: url(10.jpg) no-repeat center fixed; 
  background-size: cover;
}

body { 
  color: black; 
}
.center {
  padding: 20px 0;
  border: 3px solid red;
  text-align: center;
}
.error {color: #FF0000;}
</style>
</head>
<body>
<div class="center">
<h1>Employee Details</h1>
</div>

<?php
//database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employee_info";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$EidErr = $nameErr = $emailErr = $genderErr = "";
$Eid = $name = $email = $gender = $dateofjoining = $department = $contact = $dateofleaving= $address = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["Eid"])) {
    $EidErr = "Identification Number is required";
  } 
  else {
    $Eid = test_input($_POST["Eid"]);
  }
    // check if name only contains letters and whitespace
    
    /**$number= $_POST['number_entered'];
$form_result= $_POST['form'];

if (isset($form_result)){
if (is_numeric($number)) {
echo 'The number you entered is ' . $number. '. This is a valid number.';
}
else {
echo 'Error: You did not enter numbers only. Please enter only numbers.';
}**/

  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }

  if (empty($_POST["dateofjoining"])) {
    $dateofjoining = "";
  } else {
    $dateofjoining = test_input($_POST["dateofjoining"]);
  }
 if (empty($_POST["address"])) {
    $address = "";
  } else {
    $address = test_input($_POST["address"]);
  }
  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
}

  if (empty($_POST["department"])) {
    $department = "";
  } else {
    $department = test_input($_POST["department"]);
}
  if (empty($_POST["dateofleaving"])) {
    $dateofleaving = "";
  } else {
    $dateofleaving = test_input($_POST["dateofleaving"]);
  }
  if (empty($_POST["contact"])) {
    $contact = "";
  } else {
    $contact = test_input($_POST["contact"]);
  }

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
$sql = "INSERT INTO `employeedetails` (`Eid`, `EmployeeName`, `Date of Joining`, `Department`, `Address`, `Gender`, `ContactNo`, `Email`, `Date of Leaving`) VALUES ('$Eid', '$name', '$dateofjoining', '$department', '$address','$gender', '$contact', '$email', '$dateofleaving')";


if ($conn->query($sql) === TRUE) {
  
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>
<div class="center">
<h2>Please fill your deatils</h2>
<p><span class="error">* required field</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  Eid: <input type="number" name="Eid">
  <span class="error">* <?php echo $EidErr;?></span>
  <br><br>  
  Name: <input type="text" name="name">
  <span class="error">* <?php echo $nameErr;?></span>
  <br><br>
  E-mail: <input type="text" name="email">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
  Date of joining: <input type="text" name="dateofjoining">
  <br><br>
  Department: <input type="text" name="department">
  <br><br>
  Address: <textarea name="address" rows="5" cols="40"></textarea>
  <br><br>
  Contact: <input type="text" name="contact">
  <br><br>
  Gender:
  <input type="radio" name="gender" value="Female">Female
  <input type="radio" name="gender" value="Male">Male
  <input type="radio" name="gender" value="Other">Other
  <span class="error">* <?php echo $genderErr;?></span>
  <br><br>
  Date of leaving: <input type="text" name="dateofleaving">
  <br><br>
    <form action="upload.php" method="post" enctype="multipart/form-data">
  Select Resume to upload:
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload Image" name="submit">
</form>
 <br><br>
  <input type="submit" name="submit" value="Submit">  



</form>
</div>

<?php
echo "<h2>Your Input:</h2>";
echo $Eid;
echo "<br>";
echo $name;
echo "<br>";
echo $email;
echo "<br>";
echo $dateofjoining;
echo "<br>";
echo $department;
echo "<br>";
echo $address;
echo "<br>";
echo $contact;
echo "<br>";
echo $gender;
echo "<br>";
echo $dateofleaving;
echo "<br>";
?>
</body>
</html>
