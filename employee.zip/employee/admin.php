<?php 
include_once('connection.php'); 
$query="select * from employeedetails"; 
$result=mysqli_query($conn, $query); 
?> 
<!DOCTYPE html> 
<html> 
<style> 
html { 
  background: url(3.jpg) no-repeat center fixed; 
  background-size: cover;
}
</style>
	<head> 
		<title> Fetch Data From Database </title> 
	</head> 
	<body> 
	<table align="center" border="1px" style="width:600px; line-height:40px;"> 
	<tr> 
		<th colspan="10"><h1>Employee Record</h1></th> 
		</tr> 
			  <th> Eid </th> 
			  <th> Name </th> 
			  <th> Date of Joining </th>
			  <th> Department </th>
			  <th> Address </th>
			  <th> Gender </th>
			  <th> Contact  </th>
			  <th> Email </th> 
			  <th> Date of Leaving </th> 
			  
		</tr> 
		
		<?php while($rows=mysqli_fetch_assoc($result)) 
		{ 
		?> 
		<tr> <td><?php echo $rows['Eid']; ?></td> 
		<td><?php echo $rows['EmployeeName']; ?></td> 
		<td><?php echo $rows['Date of Joining']; ?></td> 
		<td><?php echo $rows['Department']; ?></td> 
		<td><?php echo $rows['Address']; ?></td> 
		<td><?php echo $rows['Gender']; ?></td> 
		<td><?php echo $rows['ContactNo']; ?></td> 
		<td><?php echo $rows['Email']; ?></td> 
		<td><?php echo $rows['Date of Leaving']; ?></td> 
		</tr> 
	<?php 
               } 
          ?> 

	</table> 
	</body> 
	</html>