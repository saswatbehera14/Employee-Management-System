<html>
<head>
 <title>Employee Details</title>
 <style>
 body{
 	background: url(2.jpg) no-repeat center fixed; 
    background-size: cover;
 }
 table,th,td{
 	border: 2px solid black;
 	width: 1100px;
 	background-color: lightskyblue;
 }
 .btn{
 	width: 10%;
 	height: 5%;
 	font-size: 22px;
 	padding: 0px;
 }
</style>
</head>
<body>
	<center>
		<h1 style="font-family:cursive;">Seach Employee Deatils </h1>

		<div class="container">
			<form action="" method="POST">
				<input type="text" name="Eid" class="btn" placeholder="Enter Employee ID"/>
				<input type="submit" name="search" class="btn" value="Search by ID">
			</form>
			<table>
				<tr>
					<th>Employee ID</th>
					<th>Name</th>
					<th>Date of Joining</th>
					<th>Department</th>
					<th>Address</th>
					<th>Gender</th>
					<th>ContactNo</th>
					<th>Email</th>
					<th>Date of Leaving</th>
				</tr> <br>
		    <?php
		    	$conn = mysqli_connect("localhost","root","");
		    	$db = mysqli_select_db($conn,'employee_info');


		    	if(isset($_POST['search']))
		    	{
		    		$id = $_POST['Eid'];

		    		$query = "SELECT * FROM `employeedetails` where Eid='$id' ";
		    		$query_run = mysqli_query($conn,$query);
		    		while($row = mysqli_fetch_array($query_run))
		    		{
		    		?>
		    		<tr>
		    			<td> <?php echo $row['Eid']; ?></td>
		    			<td> <?php echo $row['EmployeeName']; ?></td>
		    			<td> <?php echo $row['Date of Joining']; ?></td>
		    			<td> <?php echo $row['Department']; ?></td>
		    			<td> <?php echo $row['Address']; ?></td>
		    			<td> <?php echo $row['Gender']; ?></td>
		    			<td> <?php echo $row['ContactNo']; ?></td>
		    			<td> <?php echo $row['Email']; ?></td>
		    			<td> <?php echo $row['Date of Leaving']; ?></td>
		    			
		    		</tr>
		    		<?php
		    		}
		    	}
		    	?>
			</table>
		</div>

	</center>
</body>
</html>
